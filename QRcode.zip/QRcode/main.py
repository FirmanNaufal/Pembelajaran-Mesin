import qrcode


def generate_qr_code(data, box_size=10):
    try:
        # Validasi ukuran kotak
        if not 1 <= box_size <= 10:
            raise ValueError("Ukuran kotak harus antara 1 dan 10.")

        # Membuat instance QRCode
        qr = qrcode.QRCode(version=1, box_size=box_size, border=5)

        # Menambahkan data ke instance 'qr'
        qr.add_data(data)

        # Membuat gambar QR Code
        qr.make(fit=True)
        img = qr.make_image(fill_color='black', back_color='white')

        # Menyimpan gambar
        filename = input("Simpan sebagai (nama gambar tanpa ekstensi): ")  # Nama gambar
        img.save(f'{filename}.png')

        print('QR Code berhasil dibuat dan disimpan dalam galeri.')
    except Exception as e:
        print(f'Error: {e}')


if __name__ == "__main__":
    data = input('Masukkan Data: ')
    box_size = int(input('Masukkan Ukuran Kotak (1-10): '))
    generate_qr_code(data, box_size)
